
CREATE PROCEDURE [dbo].[getListDist]
@ColumnName varchar(200), @TableName varchar(200)
AS
BEGIN

SET NOCOUNT ON;

DECLARE @SQL nvarchar(1000);

SET @SQL = N'
				Select DISTINCT
					'+@ColumnName+' 
				From dbo.[' +@TableName + '] 
				Order by '+@ColumnName+'
				'
EXEC (@SQL)
END

go

