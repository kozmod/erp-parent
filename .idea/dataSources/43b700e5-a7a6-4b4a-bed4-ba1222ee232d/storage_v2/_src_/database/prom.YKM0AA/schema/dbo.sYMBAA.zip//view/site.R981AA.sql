-- Batch submitted through debugger: SQLQuery6.sql|9|0|C:\Users\prime\AppData\Local\Temp\~vsF204.sql

CREATE view [dbo].[Site]
 with schemabinding
as
Select 
	S.[id]
      ,S.[SiteNumber]
      ,S.[TypeHome]
      ,S.[NContract]
      ,S.[DateContract]
      ,S.[SmetCost]
      ,S.[SumCost]
      ,S.[FinishBuilding]
      ,S.[CostHouse]
      ,S.[CostSite]
      ,S.[SaleClients]
      ,S.[DebtClients]
      ,S.[StatusPayment]
      ,S.[StatusJobs]
      ,S.[QueueBuilding]
      ,S.[SaleHouse]
      ,S.[NumberSession]
      ,S.[k]
      ,S.[dell]
      ,S.[DateCreate]
      ,S.[SiteTypeID]
      ,S.[id_Count]
	  ,DCN.Name	as [Contractor]
From dbo.Site_new S
 outer apply (Select top 1 DCN.Name From [dbo].[DIC_Count_Name] DCN  (NOLOCK) Where S.id_Count= DCN.id_Count and DCN.DELL = 0 ) DCN
 
Where id_count <> -1

go

